package projeto;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import static org.omg.CORBA.AnySeqHelper.insert;

public class AcessoBD {
    private Connection con;
    private Statement stm;
    public AcessoBD(){
        con = null;
        stm = null;
    }
    
    public void conecta(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/banco_projeto?user=root");
            stm = (Statement) con.createStatement();
        }
        catch(ClassNotFoundException cnf){
            System.out.println("Exceção: " + cnf.toString());
        }
        catch(SQLException se){
            System.out.println("Exceção: " + se.toString());
        }

    }
    
    public void adiciona(cBanco produtos){  
            conecta();
            String sql = "INSERT INTO produtos( descricao, qtde, preco, marca, fornecedor) VALUES(?,?,?,?,?)";  
            try {  
                PreparedStatement stmt = con.prepareStatement(sql);  
                
                stmt.setString(1, produtos.getDescricao().trim());  
                stmt.setInt(2, produtos.getQtde());  
                stmt.setFloat(3, (float) produtos.getPreco()); 
                stmt.setString(4, produtos.getMarca().trim());
                stmt.setString(5, produtos.getFornecedor().trim());
                stmt.execute();  
                
                JOptionPane.showMessageDialog(null," Cadastrado com sucesso ! ");
                stmt.close();  
            } catch (SQLException u) {  
                throw new RuntimeException(u);  
        }  
    }  

    public ArrayList<cBanco> listProd(){
        ArrayList<cBanco> prod = new ArrayList<cBanco>();
        conecta();
        
        String sql = "SELECT * FROM produtos";
        
        Statement st;
        ResultSet rs;
        
        try{
            st = (Statement) con.createStatement();
            rs = st.executeQuery(sql);
            cBanco produtos = null;
            
            while(rs.next()){
                produtos = new cBanco();
                produtos.setCodigo(rs.getInt("codigo"));
                produtos.setDescricao(rs.getString("descricao"));
                produtos.setQtde(rs.getInt("qtde"));
                produtos.setPreco(rs.getFloat("preco"));
                produtos.setMarca(rs.getString("marca"));
                produtos.setFornecedor(rs.getString("fornecedor"));
                
                prod.add(produtos);
            }
        }
        
        catch (Exception e) {  
            e.printStackTrace();
        }  
    
        return prod;
    }
    
    public ArrayList<cBanco> list1Prod(String nome){
        ArrayList<cBanco> prod = new ArrayList<cBanco>();
        conecta();
        
        String sql = "SELECT * FROM produtos WHERE descricao LIKE '%"+nome+"%' ORDER BY descricao";
        
        Statement st;
        ResultSet rs;
        
        try{
            st = (Statement) con.createStatement();
            rs = st.executeQuery(sql);
            cBanco produtos = null;
            
            while(rs.next()){
                produtos = new cBanco();
                produtos.setCodigo(rs.getInt("codigo"));
                produtos.setDescricao(rs.getString("descricao"));
                produtos.setQtde(rs.getInt("qtde"));
                produtos.setPreco(rs.getFloat("preco"));
                produtos.setMarca(rs.getString("marca"));
                produtos.setFornecedor(rs.getString("fornecedor"));
                
                prod.add(produtos);
            }
        }
        
        catch (Exception e) {  
            e.printStackTrace();
        }  
    
        return prod;
    }
    
    
    public void attProdutos(cBanco produtos){
        
        conecta();

        try{
            String sql = "UPDATE produtos SET descricao = ?, qtde = ?, preco = ?, marca = ?, fornecedor = ? WHERE codigo = ?";
            PreparedStatement stmt = con.prepareStatement(sql);  
            
            stmt.setString(1,produtos.getDescricao());
            stmt.setInt(2,produtos.getQtde());
            stmt.setFloat(3, (float) produtos.getPreco());
            stmt.setString(4, produtos.getMarca());
            stmt.setString(5, produtos.getFornecedor());
            stmt.setInt(6, produtos.getCodigo());
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null," Alterado com sucesso ! ");
            stmt.close();
        }
        catch (Exception e) {  
            e.printStackTrace();
        }  
        
    } 
            
}
