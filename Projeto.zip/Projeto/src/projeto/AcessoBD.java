package projeto;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import static org.omg.CORBA.AnySeqHelper.insert;

public class AcessoBD {
    private Connection con;
    private Statement stm;
    public AcessoBD(){
        con = null;
        stm = null;
    }
    
    public void conecta(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/banco_projeto?user=root");
            stm = (Statement) con.createStatement();
        }
        catch(ClassNotFoundException cnf){
            System.out.println("Exceção: " + cnf.toString());
        }
        catch(SQLException se){
            System.out.println("Exceção: " + se.toString());
        }

    }
    
    public void adiciona(cBanco produtos){  
            conecta();
            String sql = "INSERT INTO produtos( descricao, qtde, preco, marca, fornecedor) VALUES(?,?,?,?,?)";  
            try {  
                PreparedStatement stmt = con.prepareStatement(sql);  
                
                stmt.setString(1, produtos.getDescricao().trim());  
                stmt.setInt(2, produtos.getQtde());  
                stmt.setFloat(3, (float) produtos.getPreco()); 
                stmt.setString(4, produtos.getMarca().trim());
                stmt.setString(5, produtos.getFornecedor().trim());
                stmt.execute();  
                stmt.close();  
            } catch (SQLException u) {  
                throw new RuntimeException(u);  
        }  
    }  

            
}
