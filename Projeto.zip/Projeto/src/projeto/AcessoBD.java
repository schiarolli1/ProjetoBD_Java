package projeto;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.awt.List;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import static org.omg.CORBA.AnySeqHelper.insert;

public class AcessoBD {
    private Connection con;
    private Statement stm;
    public AcessoBD(){
        con = null;
        stm = null;
    }
    
    public void conecta(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/banco_projeto?user=root");
            stm = (Statement) con.createStatement();
        }
        catch(ClassNotFoundException cnf){
            System.out.println("Exceção: " + cnf.toString());
        }
        catch(SQLException se){
            System.out.println("Exceção: " + se.toString());
        }

    }
    
    public void adiciona(cBanco produtos){  
            conecta();
            String sql = "INSERT INTO produtos( descricao, qtde, preco, marca, fornecedor) VALUES(?,?,?,?,?)";  
            try {  
                PreparedStatement stmt = con.prepareStatement(sql);  
                
                stmt.setString(1, produtos.getDescricao().trim());  
                stmt.setInt(2, produtos.getQtde());  
                stmt.setFloat(3, (float) produtos.getPreco()); 
                stmt.setString(4, produtos.getMarca().trim());
                stmt.setInt(5, produtos.getFornecedor());
                stmt.execute();  
                
                JOptionPane.showMessageDialog(null," Cadastrado com sucesso ! ");
                stmt.close();  
            } catch (SQLException u) {  
                throw new RuntimeException(u);  
        }  
    }  

    public ArrayList<cBanco> listProd(){
        ArrayList<cBanco> prod = new ArrayList<cBanco>();
        conecta();
        
        String sql = "SELECT * FROM produtos";
        
        Statement st;
        ResultSet rs;
        
        try{
            st = (Statement) con.createStatement();
            rs = st.executeQuery(sql);
            cBanco produtos = null;
            
            while(rs.next()){
                produtos = new cBanco();
                produtos.setCodigo(rs.getInt("codigo"));
                produtos.setDescricao(rs.getString("descricao"));
                produtos.setQtde(rs.getInt("qtde"));
                produtos.setPreco(rs.getFloat("preco"));
                produtos.setMarca(rs.getString("marca"));
                produtos.setFornecedor(rs.getInt("fornecedor"));
                
                prod.add(produtos);
            }
        }
        
        catch (Exception e) {  
            e.printStackTrace();
        }  
    
        return prod;
    }
    
    public ArrayList<cBanco> list1Prod(String nome){
        ArrayList<cBanco> prod = new ArrayList<cBanco>();
        conecta();
        
        String sql = "SELECT * FROM produtos WHERE descricao LIKE '%"+nome+"%' ORDER BY descricao";
        
        Statement st;
        ResultSet rs;
        
        try{
            st = (Statement) con.createStatement();
            rs = st.executeQuery(sql);
            cBanco produtos = null;
            
            while(rs.next()){
                produtos = new cBanco();
                produtos.setCodigo(rs.getInt("codigo"));
                produtos.setDescricao(rs.getString("descricao"));
                produtos.setQtde(rs.getInt("qtde"));
                produtos.setPreco(rs.getFloat("preco"));
                produtos.setMarca(rs.getString("marca"));
                produtos.setFornecedor(rs.getInt("fornecedor"));
                
                prod.add(produtos);
            }
        }
        
        catch (Exception e) {  
            e.printStackTrace();
        }  
    
        return prod;
    }
    
    public ArrayList<cBanco> list2Prod(String nome, String forn){
        ArrayList<cBanco> prod = new ArrayList<cBanco>();
        conecta();
        
        String sql = "SELECT * FROM produtos WHERE descricao LIKE '"+nome+"%' AND fornecedorw LIKE '"+forn+"%' ORDER BY descricao";
        
        Statement st;
        ResultSet rs;
        
        try{
            st = (Statement) con.createStatement();
            rs = st.executeQuery(sql);
            cBanco produtos = null;
            
            while(rs.next()){
                produtos = new cBanco();
                produtos.setCodigo(rs.getInt("codigo"));
                produtos.setDescricao(rs.getString("descricao"));
                produtos.setQtde(rs.getInt("qtde"));
                produtos.setPreco(rs.getFloat("preco"));
                produtos.setMarca(rs.getString("marca"));
                produtos.setFornecedor(rs.getInt("fornecedor"));
                
                prod.add(produtos);
            }
        }
        
        catch (Exception e) {  
            e.printStackTrace();
        }  
    
        return prod;
    }
    
    public ArrayList<cBanco> list3Prod(String forn){
        ArrayList<cBanco> prod = new ArrayList<cBanco>();
        conecta();
        
        String sql = "SELECT * FROM produtos WHERE fornecedor LIKE '%"+forn+"%' ORDER BY descricao";
        
        Statement st;
        ResultSet rs;
        
        try{
            st = (Statement) con.createStatement();
            rs = st.executeQuery(sql);
            cBanco produtos = null;
            
            while(rs.next()){
                produtos = new cBanco();
                produtos.setCodigo(rs.getInt("codigo"));
                produtos.setDescricao(rs.getString("descricao"));
                produtos.setQtde(rs.getInt("qtde"));
                produtos.setPreco(rs.getFloat("preco"));
                produtos.setMarca(rs.getString("marca"));
                produtos.setFornecedor(rs.getInt("fornecedor"));
                
                prod.add(produtos);
            }
        }
        
        catch (Exception e) {  
            e.printStackTrace();
        }  
    
        return prod;
    }
    
    
    public void attProdutos(cBanco produtos){
        
        conecta();

        try{
            String sql = "UPDATE produtos SET descricao = ?, qtde = ?, preco = ?, marca = ?, fornecedor = ? WHERE codigo = ?";
            PreparedStatement stmt = con.prepareStatement(sql);  
            
            stmt.setString(1,produtos.getDescricao());
            stmt.setInt(2,produtos.getQtde());
            stmt.setFloat(3, (float) produtos.getPreco());
            stmt.setString(4, produtos.getMarca());
            stmt.setInt(5, produtos.getFornecedor());
            stmt.setInt(6, produtos.getCodigo());
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null," Alterado com sucesso ! ");
            stmt.close();
        }
        catch (Exception e) {  
            e.printStackTrace();
        }  
        
    }
    
   public ArrayList popularJComboBox(){
        conecta();
        String sql = "SELECT nome FROM fornecedores";
        ArrayList<String> strList = new ArrayList<String>();
        
        try{
                 
            PreparedStatement stmt = con.prepareStatement(sql);  
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                
                strList.add(rs.getString("nome"));
            
            }
            stmt.close();
        }   
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,ex);
        }
        
        return strList;
    }
   
   public void deleteProdutos(cBanco produtos){
       
       conecta();

        try{
            String sql = "DELETE FROM produtos WHERE codigo = ?";
            PreparedStatement stmt = con.prepareStatement(sql);  
            
            stmt.setInt(1, produtos.getCodigo());
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null," Excluido com sucesso ! ");
            stmt.close();
        }
        catch (Exception e) {  
            e.printStackTrace();
        }  
       
   }
   
   public int getCodigo(String nome ){
        conecta();
        ArrayList<cBanco> prod = new ArrayList<cBanco>();
        System.out.println(""+nome);
        String sql = "SELECT codigo FROM fornecedores WHERE nome LIKE '"+nome+"'";
        cBanco produtos = null;
         
        try{
                 
            PreparedStatement stmt = con.prepareStatement(sql);  
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                
               produtos = new cBanco();
               produtos.setFornecedor(rs.getInt("codigo"));
                
               
            
            }
            stmt.close();
        }   
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,ex);
        }

        return produtos.getFornecedor();
    }

    public void adicionaFornecedor(fBanco fornecedores){  
            conecta();
            String sql = "INSERT INTO fornecedores( nome, cnpj, endereco, bairro, complemento, cidade, estado, telefone, contato, email) VALUES(?,?,?,?,?,?,?,?,?,?)";  
            try {  
                PreparedStatement stmt = con.prepareStatement(sql);  
                
                stmt.setString(1, fornecedores.getNome().trim());
                stmt.setString(2, fornecedores.getCnpj().trim());
                stmt.setString(3, fornecedores.getEndereco().trim());
                stmt.setString(4, fornecedores.getBairro().trim());
                stmt.setString(5, fornecedores.getComplemento().trim());
                stmt.setString(6, fornecedores.getCidade().trim());
                stmt.setString(7, fornecedores.getEstado());  
                stmt.setString(8, fornecedores.getTelefone().trim());
                stmt.setString(9, fornecedores.getContato().trim());
                stmt.setString(10, fornecedores.getEmail().trim());
                stmt.execute();  
                
                JOptionPane.showMessageDialog(null," Cadastrado com sucesso ! ");
                stmt.close();  
            } catch (SQLException u) {  
                throw new RuntimeException(u);  
        }  
    }  
    public ArrayList<fBanco> listFornecedor(){
        ArrayList<fBanco> fornecedores = new ArrayList<fBanco>();
        conecta();
        
        String sql = "SELECT * FROM fornecedores";
        
        Statement st;
        ResultSet rs;
        
        try{
            st = (Statement) con.createStatement();
            rs = st.executeQuery(sql);
            fBanco fornecedor = null;
            
            while(rs.next()){
                fornecedor = new fBanco();
                fornecedor.setCodigo(rs.getInt("codigo"));
                fornecedor.setNome(rs.getString("nome"));
                fornecedor.setCnpj(rs.getString("cnpj"));
                fornecedor.setCidade(rs.getString("cidade"));
                fornecedor.setEstado(rs.getString("estado"));
                fornecedor.setTelefone(rs.getString("telefone"));
                fornecedor.setContato(rs.getString("contato"));
                fornecedor.setEmail(rs.getString("email"));
                fornecedores.add(fornecedor);
            }
        }
        
        catch (Exception e) {  
            e.printStackTrace();
        }  
    
        return fornecedores;
    }
    public ArrayList<fBanco> list1Fornecedor(String nome){
        ArrayList<fBanco> fornecedores = new ArrayList<fBanco>();
        conecta();
        
        String sql = "SELECT * FROM fornecedores WHERE nome LIKE '"+nome+"%' ORDER BY nome";
        
        Statement st;
        ResultSet rs;
        
        try{
            st = (Statement) con.createStatement();
            rs = st.executeQuery(sql);
            fBanco fornecedor = null;
            
            while(rs.next()){
                fornecedor = new fBanco();
                fornecedor.setCodigo(rs.getInt("codigo"));
                fornecedor.setNome(rs.getString("nome"));
                fornecedor.setCnpj(rs.getString("cnpj"));
                fornecedor.setCidade(rs.getString("cidade"));
                fornecedor.setEstado(rs.getString("estado"));
                fornecedor.setTelefone(rs.getString("telefone"));
                fornecedor.setContato(rs.getString("contato"));
                fornecedor.setEmail(rs.getString("email"));
                fornecedores.add(fornecedor);
            }
        }
        
        catch (Exception e) {  
            e.printStackTrace();
        }  
    
        return fornecedores;
    }
    
    public ArrayList<fBanco> list2Fornecedor(String cnpj){
        ArrayList<fBanco> fornecedores = new ArrayList<fBanco>();
        conecta();
        
        String sql = "SELECT * FROM fornecedores WHERE cnpj LIKE '"+cnpj+"%' ORDER BY nome";
        
        Statement st;
        ResultSet rs;
        
        try{
            st = (Statement) con.createStatement();
            rs = st.executeQuery(sql);
            fBanco fornecedor = null;
            
            while(rs.next()){
                fornecedor = new fBanco();
                fornecedor.setCodigo(rs.getInt("codigo"));
                fornecedor.setNome(rs.getString("nome"));
                fornecedor.setCnpj(rs.getString("cnpj"));
                fornecedor.setCidade(rs.getString("cidade"));
                fornecedor.setEstado(rs.getString("estado"));
                fornecedor.setTelefone(rs.getString("telefone"));
                fornecedor.setContato(rs.getString("contato"));
                fornecedor.setEmail(rs.getString("email"));
                fornecedores.add(fornecedor);
            }
        }
        
        catch (Exception e) {  
            e.printStackTrace();
        }  
    
        return fornecedores;
    }
    public ArrayList<fBanco> list3Fornecedor(String nome, String cnpj){
        ArrayList<fBanco> fornecedores = new ArrayList<fBanco>();
        conecta();
        
        String sql = "SELECT * FROM fornecedores WHERE nome LIKE '"+nome+"%' AND cnpj LIKE '"+cnpj+"%' ORDER BY nome";
        
        Statement st;
        ResultSet rs;
        
        try{
            st = (Statement) con.createStatement();
            rs = st.executeQuery(sql);
            fBanco fornecedor = null;
            
            while(rs.next()){
                fornecedor = new fBanco();
                fornecedor.setCodigo(rs.getInt("codigo"));
                fornecedor.setNome(rs.getString("nome"));
                fornecedor.setCnpj(rs.getString("cnpj"));
                fornecedor.setCidade(rs.getString("cidade"));
                fornecedor.setEstado(rs.getString("estado"));
                fornecedor.setTelefone(rs.getString("telefone"));
                fornecedor.setContato(rs.getString("contato"));
                fornecedor.setEmail(rs.getString("email"));
                fornecedores.add(fornecedor);
            }
        }
        
        catch (Exception e) {  
            e.printStackTrace();
        }  
    
        return fornecedores;
    }
            
}
